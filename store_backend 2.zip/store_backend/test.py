def younger_person():
    ages = [12,42,32,58,56,14,78,30]
    print(min(ages))
    print(len(ages))
    print(sum(ages))

younger_person()

def print_some_nums():
    for y in range(10):
        print(y)
