catalog = [
    {
        "_id": "ioqpeufdkvhacjkbheaiuvn",
        "title": "Food",
        "price": 15.99,
        "stock": 12,
        "category": "crazy",
        "image": "https://m.media-amazon.com/images/I/71cXTVpisbL._AC_UL320_.jpg"
    },
    {
        "_id": "mcvzbxkljhfew",
        "title": "Animal print",
        "price": 24.99,
        "stock": 12,
        "category": "crazy",
        "image": "https://m.media-amazon.com/images/I/81GUcRogYlL._AC_UL320_.jpg"
    },
    {
        "_id": "poiyuhfdjsambc",
        "title": "Baby yoda",
        "price": 5.99,
        "stock": 12,
        "category": "crazy",
        "image": "https://m.media-amazon.com/images/I/81HRFY9Mj0L._AC_UL320_.jpg"
    },
    {
        "_id": "fgcdasuiytfduaik",
        "title": "Wonder socks",
        "price": 11.99,
        "stock": 12,
        "category": "test",
        "image": "https://m.media-amazon.com/images/I/61KuRIWAnSL._AC_UL320_.jpg"
    },
    {
        "_id": "uryfijdakvsbczn",
        "title": "Puppy socks",
        "price": 8.99,
        "stock": 12,
        "category": "crazy",
        "image": "https://m.media-amazon.com/images/I/71ZdYaXG3ZL._AC_UL320_.jpg"
    },
    {
        "_id": "vbcbvjkergrtruy",
        "title": "Funny socks",
        "price": 6.99,
        "stock": 12,
        "category": "crazy",
        "image": "https://m.media-amazon.com/images/I/71fgKyA32OL._AC_UL320_.jpg"
    },
    {
        "_id": "ioqpeufdkvhacjkoiytpe4usygfvcahxcvbheaiuvn",
        "title": "Valentines",
        "price": 19.99,
        "stock": 12,
        "category": "test",
        "image": "https://m.media-amazon.com/images/I/61U72S5e92L._AC_UL320_.jpg"
    },
    {
        "_id": "rtwydfgchajbvnfs",
        "title": "Animal socks",
        "price": 22.99,
        "stock": 12,
        "category": "crazy",
        "image": "https://m.media-amazon.com/images/I/61dX+qyIyCL._AC_UL320_.jpg"
    },
    {
        "_id": "cvhksjzjhfgiorewpyup",
        "title": "Pattern socks",
        "price": 12.99,
        "stock": 12,
        "category": "crazy",
        "image": "https://m.media-amazon.com/images/I/81PwrFH-DmL._AC_UL320_.jpg"
    },
    {
        "_id": "nbvdjlhfuwehgvzcxbvhefigjbhvn",
        "title": "Pencil socks",
        "price": 15.99,
        "stock": 12,
        "category": "test",
        "image": "https://m.media-amazon.com/images/I/71tyMSnw8vS._AC_UL320_.jpg"
    }]