def test_dict():
    me = {
        'first': 'Trey',
        'last': 'Schneider',
        'age': 26,
    }